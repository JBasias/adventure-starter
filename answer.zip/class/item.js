class Item {


  constructor(name, description)
  {
    this.name = name;
    this.description = description;
  }
    // Fill this in

}

module.exports = {
  Item,
};
